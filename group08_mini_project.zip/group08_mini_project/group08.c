#include <util/delay.h>
#include <avr/io.h>
#include <stdbool.h>
#include <time.h>
#include <stdlib.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>	//interrupt header file
#include <string.h>
#include "lcd.h"

#define SOLID_TRACK 4
#define SOLID_TRACK_RIGHT 5
#define SOLID_TRACK_LEFT 6
#define SOLID_TRACK_BLANK ' '

/* Functions */
void choise1();			//play game
void choise2();			//change difficulty
void choise3();			//change volume
void choise4();			//edit username
void choise5();			//leaderboard
void highscore1();		//easy mode
void highscore2();		//medium mode
void highscore3();		//hard mode
void scoreprint(int d);	//print leaderboards
void invalid();			//if invalid choise
void getusername();		//getting username
void volume();			//change volume
void changeDif();		//change difficulty
void brightness();		//brightness function
void leaderboard(int d,char name[],int scor);	//update leaderboard

void buz_splashscreen(int v);	//sound for splash sreen
void buz_start(int v);			//sound for start game
void buz_over(int v);			//sound for game over
void buz_highest(int v);		//sound

void delay(int routine);		//custom delay function

/* Global Variables */
static char lineupper[17];		//LCD upper line
static char linelower[17];		//LCD bottom line
static int buttonPushed = 0;	//push button interrupt signal

char user[5];	//store username
int select=0,t,tim,count,diff,volume_level;//diff to difficulty 1,2,3
char choise;
int score=0;	//store score
char menu1[]="1.Start Game";
char menu2[]="2.Difficulty";
char menu3[]="3.Change Volume";
char menu4[]="4.Edit Username";
char menu5[]="5.High scores";
char press[]="<-4   OK #   6->";
char submenu1[]="1.Easy";
char submenu2[]="2.Moderate";
char submenu3[]="3.Hard";

void initializeGraphics(){		//for custom graphics
static const PROGMEM unsigned char Hero_Design[] = {
	
    											// Run position 1
	0x00,0x00,0x00,0x00,0x04,0x0E,0x19,0x1F,
    											// Run position 2
	0x04,0x0E,0x19,0x1F,0x1E,0x0E,0x0A,0x0B,
    											// Jump
	0x04,0x0E,0x19,0x1F,0x1E,0x0E,0x0A,0x0B,
   	 											// Jump lower
	0x0E,0x0A,0x0B,0x00,0x00,0x00,0x00,0x00,
    											// Ground
	0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,0x1F,
    											// Ground right
	0x03,0x03,0x03,0x03,0x03,0x03,0x03,0x03,
    											// Ground left
	0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,

	0x00,0x00,0x00,0x00,0x04,0x0E,0x19,0x1F,
  };

  int i;

	lcd_command(_BV(LCD_CGRAM));  // set CG RAM start address 0 
	for(int i=0; i<56; ++i){
		lcd_data(pgm_read_byte_near(&Hero_Design[i]));	// creating graphics
	}

  for (i = 0; i < 16; ++i) {		//set initial lines empty 
    lineupper[i] = ' ';
    linelower[i] = ' ';
  }
}


/* Keypad array */
char keypad[4][4] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};

/* Define corresponding pins of rows and column */
int rowPins[4] = { 0, 1, 2, 3 };// ROW0 = PB0, ROW1 = PB1, ROW2 = PB2, ROW3 = PB3
int colPins[4] = { 4, 5, 4, 5 };// COL0 = PB4, COL1 = PB5, COL2 = PC4, COL3 = PC5

/* Function to take keypad input and return charater */
char keypad_input(){	
	int i,j;
	while(1){
		for (i = 0; i < 4; i++){
			PORTB =PORTB & ~( (1<<0)|(1<<1)|(1<<2)|(1<<3) );
			PORTB |= 1<<(rowPins[i]);			//make corresponding row High
			for (j = 0; j < 4; j++) {
				if (j < 2){
					if(PINB & (1<<colPins[j])){	//check column high or low
						delay(100);
						return (keypad[i][j]);
					}
				}else{
					if(PINC & (1<<colPins[j])){
						delay(100);
						return (keypad[i][j]);
					}
				}
			}
		}
	}
}

/* Function for delay of 2ms */
void delay_timer0(){ 
	TCNT0 = 131; 				//set initial counter value 
	TCCR0A = 0x00; 				//set timer0 normal mode 
	TCCR0B = 0x04; 				//set timer0 prescaler 1 : 256 
	while((TIFR0 & 0x01)==0 ); 	//wait till counter overflow 
	TCCR0A = 0x00; 				//clear timer0 setting and stop timer 
	TCCR0B = 0x00; 
	TIFR0 = 0x01;				//set to 1: clear timer0 overflow 0th bit 
} 

/* Function for custom delay */
void delay(int routine){ 	
	for(int i = 0; i < routine/2; i++){ 
	delay_timer0(); 
	} 
} 

/* Function to write integer to the EEPROM */
void EEPROM_write_number(unsigned int address , int data){	
	// write integer to EEPROM
    //address is 16bits 2Bytes 
    //data is 8bits 1Byte
    //wait for previous write is done
    //wait untill EEPROM write Enable bit is zero in EEPROM Control Register
    while (EECR & (1<<EEPE));
    //set up address reg
    EEAR = address;
    EEDR = data;
    // Write logical one to EEMPE (EEPROM MASTER WRITE ENABLE)
    //Without this EEPE has no effect
    EECR |= (1<<EEMPE);
    //Start eeprom write by setting EEPE (EEPROM WRITE ENABLE)
    EECR |= (1<<EEPE);
}

/*Function to write on EEPROM*/
void EEPROMwrite(unsigned int address, char data){
    /*wait untill completion of previous write*/
    while (EECR & (1<<EEPE));

    /*Assign 16bit address and 8 bit data to EE address register and data register*/
    EEAR = address;
    EEDR = data;

    /*write logic 1 to EEPROM master write enable*/
    EECR |= (1<< EEMPE);
    /*start write to the EEPROM*/
    EECR |= (1<<EEPE); 
}

/*Function to read from EEPROM*/
char EEPROMread(unsigned int address){
    /*wait untill completion of previous write*/
    while(EECR & (1<<EEPE));
    /*assign address value to address register in control register*/
    EEAR = address;
    /*start reading from EEPROM*/
    EECR |= (1<<EERE);
    /*return the data stred in the data register*/
    return EEDR;
}


void buzzerPWM_init(){       //  PWM for Buzzer
    TCCR1A |= (1<<WGM00) | (1<<WGM01);        //select fast PWM mode in timer 0
    TCCR1B &= ~(1<<WGM02);

    TCCR1A |= (1<<COM0A1) ;
    TCCR1A &= ~(1<<COM0A0);     //select COM0 is 10 non inverting mode
}
void initPWM(){		// intializing PWM for brightness
	TCCR0A |= (1<<WGM00) | (1<<WGM01);	//select fast PWM mode in timer 0
	TCCR0B &= ~(1<<WGM02);

	TCCR0A |= (1<<COM0A1) ;
	TCCR0A &= ~(1<<COM0A0); 	//select COM0 is 10 non inverting mode
	
	TCCR0B |= 0x03;  //select clock to 1:64 prescaler CS02:0 = 011
}

/* Initialize Analog to Digital Converter */
void init_ADC(){		
    ADCSRA |= (1<<ADEN);    						//enable ADC module
    /*  Frequency of oscillator = 16 MHz
        Clock frequency must be less than 200kHz
        Therefore prescaler value range is x, 
            Then,   16000/200 = 80 < x
            Suitable prescaler x = 128
        ADPS2:0 = 111 for prescaler 1:128
    */
    ADCSRA |= (1<<ADPS2)|(1<<ADPS1)|(1<<ADPS0);     //selecting conversion speed 125kHz by prescaler 1:128

    ADMUX |= (1<<REFS0);
    ADMUX &= ~(1<<REFS1);                  //Select voltage reference as AVCC with external capacitor at AREF pin

    ADMUX |= ((1<<MUX0)|(1<<MUX1));
    ADMUX &= ~((1<<MUX3)|(1<<MUX2));  		//Select ADC input channel as ADC3

    ADMUX |= (1<<ADLAR);        			//left justify    
}

/* Initialize Universal Serial communication */
void usart_init(void){		 
    /* set BAUD rate*/ 
    UBRR0L =  103;
    /* enable reciever and transmitter */
    UCSR0B |= (1<<RXEN0);
    UCSR0B |= (1<<TXEN0);
    /* set frame format: acynchronous mode, 8 bit data, no parity, 1 stop bit  */
    UCSR0C = 0b00000110;
    
}

/* Function to recieve data through serial port */
char usart_receive(void){		
    /* wait for data to be received */
    while((UCSR0A & (1<<RXC0))==0);
    /* return the recieved data from the buffer */
    return UDR0;
}

/* Function to send data through serial port */
void usart_send(char data){		//USART send
    /* wait for transmit buffer to be empty */
    while ((UCSR0A  & (1<<UDRE0))==0);
    /* put data into buffer and send */
    UDR0 = data;
}

/*Function to transfer string to PC*/
void transfer(unsigned char Data[]){	
	for(int i = 0; i<strlen(Data); i++){
    		usart_send(Data[i]);
  	}
}

/* Function to generate random numbers in range (lower, upper) */
int random_number(int lower, int upper){
	int num = (rand()%(upper - lower + 1)) + lower;
	return num;
}

/* Function to scroll obstacle to the left in half character increment */
void shift_obstacle(char* obstacle, char new_obstacle){
	/* Loop untill 16 blocks and smooth the obstacle shift */
	for (int i = 0; i < 16; ++i) {
		char current = obstacle[i];
		char next;
		/* if lcd block reach 15, generate new obstacle routine */
		if(i == 15){
			next = new_obstacle;
		}else{
			next = obstacle[i+1];
		}
		/* create half right block before full block or gap */
		if (current == SOLID_TRACK_BLANK){
			if(next == SOLID_TRACK){
				obstacle[i] = SOLID_TRACK_RIGHT;
			}else{
				obstacle[i] =SOLID_TRACK_BLANK;
			}
		/* create half left block before gap and else create full block */
		}else if(current == SOLID_TRACK){
			if(next == SOLID_TRACK_BLANK){
				obstacle[i] = SOLID_TRACK_LEFT;
			}else{
				obstacle[i] = SOLID_TRACK ;
			}
		/* create full solid block afer right half block */
		}else if(current== SOLID_TRACK_RIGHT){
			obstacle[i] = SOLID_TRACK;
		/* create gap after half left solid block */
		}else if(current== SOLID_TRACK_LEFT){
			obstacle[i] = SOLID_TRACK_BLANK;
		}
	}
}

/* Function to place the hero and return the result collide */
int place_hero(char position, char* lineupper, char* linelower,int score) {
	/* local variables */
	int collide = 0;
	char upperSave = lineupper[1];
	char lowerSave = linelower[1];
	char upper, lower;			
	char buffer[3];				// For score

	/* conditions to place hero position */
	if(position==0){
		upper = lower = SOLID_TRACK_BLANK;
	}else if(position==1){
		upper = SOLID_TRACK_BLANK;
		lower = 1;
	}else if(position== 2){
		upper = SOLID_TRACK_BLANK;
		lower = 2;
	}else if( (position==3)||(position==10) ){
		upper = SOLID_TRACK_BLANK;
		lower = 3;
	}else if( (position==4)||(position==9) ){
		upper = 8;
		lower = 3;
	}else if( (position==5)||(position==6)||(position==7)||(position==8) ){
		upper = 3;
		lower = SOLID_TRACK_BLANK;    
	}else if(position==11){
		upper = 1;
		lower = SOLID_TRACK_BLANK;
	}else if(position==12){
		upper = 2;
		lower = SOLID_TRACK_BLANK;
	}
	/* condition to check for collision in flying */
	if (upper != ' ') {
		lineupper[1] = upper;			//update line upper value
		if (upperSave == ' '){	
			collide = 0;
		}else{
			collide = 1;
		}
	}
	/* condition to chcek for collision in ground*/
	if (lower != ' ') {
		linelower[1] = lower;			//update line lower value
		if(lowerSave != ' '  &&  collide==0){
			collide = 1;
		}
	}
	/* define digits of score value */
  	int digits;
  	if(score > 99){
		digits = 3;
  	}
	else if(score > 9){
		digits = 2;
  	}
	else{
		digits = 1;
  	}

  	/* Display of game play screen */
  	lineupper[16] = '\0';
  	linelower[16] = '\0';
	
  	char temp = lineupper[16-digits];	//allocate space for score in the upper array 
  	lineupper[16-digits] = '\0';
  	lcd_gotoxy(0,0);
  	lcd_puts(lineupper);
  	lineupper[16-digits] = temp; 		//only use space with out score blocks 
  	lcd_gotoxy(0,1);
  	lcd_puts(linelower);
  	lcd_gotoxy(16 - digits,0);

	/* display score on right top corner of lcd */
  	char buffer1[3];
  	itoa( score , buffer1, 10);			//change score from iteger to character
  	lcd_puts(buffer1);

  	lineupper[1] = upperSave;
  	linelower[1] = lowerSave;			//reassign

  	return collide;						//return integer collision flag 
}

/* Function to play the game */
void game(int d){	
	/* External interrupt using push button */
	DDRD &= ~(1<<2);		//pin PD2 is input								
  	EICRA &= ~(1<<ISC00);	//set for falling edge		
  	EICRA |= (1<<ISC01);	//set for falling edge		
  	sei();					//enable global interrupts	
	EIMSK |= (1<<INT0);		//enable interrupts for INT0

	while(1){
		lcd_clrscr();
		brightness(); //-------?

	
		static int hero_position = 1;
		static int new_obstacle_type = 0;
		static int new_obstacle_duration = 1;
		static int playing = 0;
		static int over = 0;
		static int blink = 0;
		static int distance = 0;
		static int jump = 0;

		/* before starting play */
		while(playing == 0) {
			if(blink == 0){	
				place_hero(0, lineupper, linelower, score);
				buz_start(volume_level);
			}
			else if(blink == 1){
				place_hero(hero_position, lineupper, linelower, score);
			}
			if (blink == 0) {
				lcd_clrscr();
				lcd_gotoxy(0,0);
				lcd_puts("Press Start");
			}
			delay(250);
			if(blink == 0){
				blink = 1;
			}
			else if(blink == 1){
				blink = 0;
			}
			/* start generate hero design */
			if (buttonPushed !=0) {
				initializeGraphics();
				hero_position = 1;
				playing = 1;			//flag to start generate obstacle
				buttonPushed = 0;
				distance = 0;
			}
		}

		/* start generating and sliding obstacles */
		if(new_obstacle_type == 1){
			shift_obstacle(linelower, SOLID_TRACK);
		}
		else{
			shift_obstacle(linelower, ' ');
		}

		if(new_obstacle_type == 2){
			shift_obstacle(lineupper,  SOLID_TRACK );
		}
		else{
			shift_obstacle(lineupper,  ' ');
		}

		/* generate new obstacle to enter on the right */
		int speed = --new_obstacle_duration;
		if ( speed == 0) {
			if (new_obstacle_type == 0) {
				if(random_number(0,2) == 0){			
					new_obstacle_type = 2;
				}
				else{
					new_obstacle_type =1;
				}
				new_obstacle_duration = 2 + random_number(0,9);
			}
			else{
				new_obstacle_type = 0;
				new_obstacle_duration = 10 + random_number(0,9);
			}
		}
    /* position of hero while push button is pressed */
	if (buttonPushed !=0) {
		if (hero_position <= 2){
			hero_position = 3;
		}
		buttonPushed = 0;

		score = jump*d;				//multiply score with difficulty
 		char buffer3[3]="\n";		
		itoa( score , buffer3, 10);
		transfer(buffer3);			// send curret score to PC while playing
		transfer("\n");
		jump++;						// increment jump count
	}  
	/* condition to game over - collide = 1*/
	if (place_hero(hero_position, lineupper, linelower, score ) != 0) {
		playing = 0; // The hero collided with something
		over = 1;

		delay(2000);

		lcd_clrscr();
		lcd_gotoxy(0,0);  
		lcd_puts("  GAME OVER!!!  ");// print game over

		buz_over(volume_level);//buzzer sound for game over

		if(score >= EEPROMread(500+d)){	//Check for highest score
			lcd_gotoxy(0,1);
			lcd_puts("Congrats!");	//additional messege if highest score

			buz_highest(volume_level);		//buzzer sound for highest score

			transfer("Well Done!\nYour Score - \n");// To PC 
			delay(3000);
			lcd_clrscr();
			lcd_gotoxy(0,0);  
			lcd_puts(" Highest Score! ");

		}
		else{
			transfer("Game Over!!!\nYour Score-"); // game over message to PC

		}
		/*print score on LCD and sent to PC*/
		lcd_gotoxy(0,1);
		lcd_puts("Your score-");	//print score on LCD
		lcd_gotoxy(11,1);
  		char buffer1[3];
		itoa( score , buffer1, 10);
		lcd_puts(buffer1);

  		char buffer4[3]="\n";		
		itoa( score , buffer4, 10);
		transfer(buffer4);			//print score on PC
		transfer("\n");

		/* update EEPROM with current difficulty level, user name, score*/
		leaderboard(d, user ,score);
		/* reset the score and jump count for next play */
		delay(3000);	
		score = 0;
		jump = 0;	
		choise1();				//start the game menu

		}
	/* continue play */
	else{
		if (hero_position == 2 || hero_position == 10) {
			hero_position = 1;
		} else if ((hero_position >= 5 && hero_position <= 7) && linelower[1] != ' ') {
			hero_position = 11;
		} else if (hero_position >= 11 && linelower[1] == ' ') {
			hero_position = 7;
		} else if (hero_position == 12) {
			hero_position = 11;
		} else {
			++hero_position;
		}
	}
	/* changing speed according to difficulty */
	if(d == 1){			
		delay(200);
	}else if(d == 2){
		delay(100);
	}else if(d == 3){
		delay(50);
	}

}

}

/* Function to get minimum element of and array*/
int minimum(int a[]){	
	int min,i,index = 0;
	min=a[0];
	/*check difference of leaderboard scores and score */
	for(i=1; i<10; i++){
		if(min > a[i]){
			min = a[i];
			index = i;
		}     
	}
    return index;			//return the position to write the score where low score saved
 }	

/* Function to update leaderboard according to the difficulty level */
void leaderboard(int d,char name[],int scor){
	int Pos,Epos;				//variables for current score position and EEPROM 
	int gap[10];				//integer array to have difference of current score with leaderboard
	
	/* generate gap array */
	for(int i=0;i<10;i++){
		Epos = (150*(d-1)) + (i*10) +10;		//formula for navigate EEPROM leaderboard scores
		gap[i] = EEPROMread(Epos) - scor;
	}
	
	Pos = minimum(gap);		//position of minimum gap score position on EEPROM

	if( scor > EEPROMread( (150*(d-1)) + (Pos*10) + 10 ) ){	//compare new sore with previous min score
		EEPROM_write_number( (150*(d-1)) + (Pos*10) + 10,scor); //write new socre
		EEPROMwrite( (150*(d-1)) + (Pos*10) + (9) , '-' );
		for(int j=0;j<5;j++){
			EEPROMwrite( (150*(d-1)) + (Pos*10) + (3+j) , name[j] );	//write new username
		}
	}
}

/* Function to print highest 10 scores according to the difficulty level */
void scoreprint(int d){	   // d is selected difficulty level 
	int order[10];
	int i, j, a;
	int number[10];
	int marks[10];	
	/* Sorting algorithm start to  create position array of leaderboard in descending order*/	 				
	for(i=0;i<10;i++){					
		number[i] = EEPROMread( (150*(d-1)) + (i*10) +10 ); // write scores to number array 
		marks[i] = number[i];		//marks array is copy of number array			
	}								
	/* sort number array in descending order */
    for (i = 0; i < 10; ++i){			
        for (j = i + 1; j < 10; ++j){	
	        if (number[i] < number[j]){ 
	            a = number[i];			
	            number[i] = number[j];	
	            number[j] = a;			
	        }							
	    }								
    }	
	/* create rank array */								
	for (i = 0; i < 10; i++){			
        for(j = 0; j < 10 ; j++){				
            if(number[i] == marks[j]){	
                marks[j] = 0;				
                order[i] = j;	//create rank array			
                break;					
            }							
        }								
    }									
	/* Sorting algorithm end to  create position array of leaderboard in descending order*/
	
	/* save the highest score of difficulty level to seperate EEPROM position */
	EEPROM_write_number(500+d,EEPROMread( (10*order[0])+ (10) +((d-1)*150)));
	char EtoPC[10];
	int p = 0;

	/* initially printing highest score */
	lcd_clrscr();		
	lcd_gotoxy(0, 0);
	char buf[5];
	itoa( p+1 , buf, 10);		//change integer to character
	lcd_puts(buf);				//print rank
	lcd_gotoxy(2, 0);
	lcd_putc(' ');
	lcd_gotoxy(3, 0);

	for(int k = 3;	k <=9; k++){		//read username characters
		EtoPC[k-3] = EEPROMread( (10*order[p])+ (k) +((d-1)*150));
	}

	char buf1[2];
	itoa( EEPROMread( (10*order[p])+ (10) +((d-1)*150)) , buf1, 10);	//read score
	lcd_puts(EtoPC);			//display username
	lcd_gotoxy(9, 0);
	lcd_putc('-');
	lcd_gotoxy(10, 0);
	lcd_puts(buf1);				//display score

	/* display blank when rank exceed limit */
	if(EEPROMread( (10*order[p])+ (10) +((d-1)*150)) >9){
		lcd_gotoxy(12, 1);
		lcd_puts("    ");
	}else{
		lcd_gotoxy(11, 1);
		lcd_puts("     ");
	}
	lcd_gotoxy(0, 1);
	lcd_puts("<-4  *-Back  6->");	//display navigation note
	choise = keypad_input();		//get keypad input
	delay(100);

	/* Start navigate in leader board*/
	while(1){				
		choise	=	keypad_input();	//get input
		delay(100);
		/* increase or decrease rank 'p' according to keypad input*/
		if(choise=='*'){		
			choise5();			
		}else if(choise=='6'){	
			p = p+1;				
		}else if(choise=='4'){	
			p = p-1;				
		}						
								
		if(p < 0){				
			p = 9;				
		}else if(p > 9){			
			p = 0;				
		}						

		lcd_clrscr();
		lcd_gotoxy(0, 0);
		char buf[5];
		itoa( p+1, buf, 10);
		lcd_puts(buf);			//display rank
		lcd_gotoxy(2, 0);
		lcd_putc(' ');
		lcd_gotoxy(3, 0);

		for(int k = 3; k <= 9; k++){		//read username from EEPROM
			EtoPC[k-3]=EEPROMread( (10*order[p])+ (k) +((d-1)*150));
		}
		char buf2[2];						//read score from EEPROM			
		itoa( EEPROMread( (10*order[p])+ (10) +((d-1)*150)) , buf2, 10);
		lcd_puts(EtoPC);					//display username
		lcd_gotoxy(9, 0);
		lcd_putc('-');
		lcd_gotoxy(10, 0);
		lcd_puts(buf2);						//display score
		/* condition for rank exceed limit 10 */
		if(EEPROMread( (10*order[p])+ (10) +((d-1)*150)) >9){
			lcd_gotoxy(12, 1);
			lcd_puts("    ");
		}else{
			lcd_gotoxy(11, 1);
			lcd_puts("     ");
		}
		lcd_gotoxy(0, 1);
		lcd_puts("<-4  *-Back  6->");	//display navigation note
	}
	/* end of leaderboard navigation */
}

/* Function to create tune for splash screen */
void buz_splashscreen(int v){ 
	/* initialize PWM for buzzer */
	buzzerPWM_init();       
	int val;
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts("!    JUMPING   !");
	lcd_gotoxy(0, 1);
	lcd_puts("!!    GAME    !!");
	/* assign output compare match value */	
	val = 250*v/100;
    OCR1A = val;
    TCCR1B = 0x02;  		//frequency = 7812.5 Hz
    delay(700);   			//keep for 1s
	lcd_clrscr();

	/* change compare match value*/
	val = 63*v/100;
    OCR1A = val;
    TCCR1B = 0x04;  		//frequency = 245.141 Hz
    delay(700);   			//keep for 1s

	/* repeat the tune*/
	lcd_gotoxy(0, 0);	
	lcd_puts("!    JUMPING   !");
	lcd_gotoxy(0, 1);
	lcd_puts("!!    GAME    !!");
	
	val=250*v/100;
    OCR1A = val;
    TCCR1B = 0x02;  //frequency = 7812.5 Hz
    delay(700);   //keep for 1s


	lcd_clrscr();
	val=63*v/100;
    OCR1A = val;
    TCCR1B = 0x04;  //frequency = 245.141 Hz
    delay(700);   //keep for 1s

	lcd_gotoxy(0, 0);	
	lcd_puts("!    JUMPING   !");
	lcd_gotoxy(0, 1);
	lcd_puts("!!    GAME    !!");
	
	val=200*v/100;
    OCR1A = val;
    TCCR1B = 0x03;  //frequency = 976.56 Hz
    delay(3000);   //keep for 1s
	lcd_clrscr();

	delay(500);
    OCR1A = 0;		//set compare match to 0

    TCCR1A = 0;        //reset fast PWM mode in timer 0
    TCCR1B = 0;
}
/* Function to create tune for start the game */
void buz_start(int v){    
	/* initialize PWM  */
	buzzerPWM_init();       
	int val;
    val = 63*v/100;
    OCR1A = val;
    TCCR1B = 0x04;  //frequency = 245.141 Hz
    delay(1000);   //keep for 1s
	val = 200*v/100;
    OCR1A = val;
    TCCR1B = 0x03;  //frequency = 976.56 Hz
    delay(1000);   //keep for 1s
	val = 250*v/100;
    OCR1A = val;
    TCCR1B = 0x02;  //frequency = 7812.5 Hz
    delay(1000);   //keep for 1s

    OCR1A = 0;

    TCCR1A =0;        //reset fast PWM mode in timer 0
    TCCR1B =0;
}

/*Function to create tune for game over*/
void buz_over(int v){   
	//initializing PWM for Buzzer
	buzzerPWM_init();       
	int val;
	val = 250*v/100;
    OCR1A = val;
    TCCR1B = 0x02;  //frequency = 7812.5 Hz
    delay(1000);   //keep for 1s
    OCR1A = val;
    TCCR1B = 0x03;  //frequency = 976.56 Hz
    delay(1000);   //keep for 1s
    OCR1A = val;
    TCCR1B = 0x04;  //frequency = 245.141 Hz
    delay(1000);   //keep for 1s

    OCR1A = 0; //stop

    TCCR1A =0;        //reset fast PWM mode in timer 0
    TCCR1B =0;
}

/* Function to create tune for high score */
void buz_highest(int v){    //Buzzer sound for highest score
	buzzerPWM_init();       //initializing PWM for Buzzer
	int val;
		val=250*v/100;
        OCR1A = val;
        TCCR1B = 0x04;  //frequency = 245.141 Hz
        delay(1000);   //keep for 1s

        OCR1A = val;
        TCCR1B = 0x03;  //frequency = 976.56 Hz
        delay(1000);   //keep for 1s

        OCR1A = val;
        TCCR1B = 0x02;  //frequency = 7812.5 Hz
        delay(1000);   //keep for 1s


        OCR1A = 0; //stop

    TCCR1A =0;        //select fast PWM mode in timer 0
    TCCR1B =0;
}

/* Function for auto brightness */
void brightness(){	
	DDRD |= (1<<6);  	//set PD6 as output pin for timer/counter 0 compare match A 
	DDRC &= ~(1<<3);    //assign pin 3 of port C as input
	
	initPWM();
        
	ADCSRA |= (1<<ADSC);
    if(ADCSRA & (1<<ADIF)){   //execute when anolog signal convereted to digital and interupt fald become high
        OCR0A =(5*ADCH+790)/12;     //set duty cycle in affective ADCH range
		ADCSRA |= (1<<ADSC);        //Start conversion
	}
    
}

/* Function to change difficulty*/
void changeDif(){		
	while(1){
		char input;
		lcd_clrscr();
		lcd_gotoxy(0,0);  
		lcd_puts("Easy|Medium|Hard");
		lcd_gotoxy(0,1);
		lcd_puts(" 1     2     3  ");  

		//showing current difficulty by star mark(*)
		if(EEPROMread(500)==1){		
			lcd_gotoxy(2,1);
			lcd_puts("*");
		}else if(EEPROMread(500)==2){
			lcd_gotoxy(8,1);
			lcd_puts("*");
		}else if(EEPROMread(500)==3){
			lcd_gotoxy(14,1);
			lcd_puts("*");
		}

		delay(1000);
		input = keypad_input();
		delay(100);
		if(input =='1'){				// set difficulty to 1
			EEPROM_write_number(500,1);
			diff = EEPROMread(500);
			choise2();
		}else if(input =='2'){		// set difficulty to 2
			EEPROM_write_number(500,2);
			diff = EEPROMread(500);
			choise2();
		}else if(input =='3'){		// set difficulty to 3
			EEPROM_write_number(500,3);
			diff = EEPROMread(500);
			choise2();
		}else{
			invalid();				//invalid option
		}	
	}
}

/* Function to change the volume */
void volume(){	
	while(1){
		char input;
		lcd_clrscr();
		lcd_gotoxy(0,0);  
		lcd_puts("Mut|Low|Med|High");
		lcd_gotoxy(0,1);
		lcd_puts(" 0   1   2   3  ");  
		//showing current Volume level by star mark(*) by comparing previous select of volume
		if(EEPROMread(600) == 100){			// 100 for High
			lcd_gotoxy(14,1);
			lcd_puts("*");
		}else if(EEPROMread(600) == 67){	// 67 for Medium
			lcd_gotoxy(10,1);
			lcd_puts("*");
		}else if(EEPROMread(600) == 33){	// 33 for low
			lcd_gotoxy(6,1);
			lcd_puts("*");
		}else if(EEPROMread(600) == 0){		// 0 for mute
			lcd_gotoxy(2,1);
			lcd_puts("*");
		}

		delay(1000);
		input = keypad_input();
		delay(100);
		if(input =='3'){				// set volume to 1
			EEPROM_write_number(600,100);
			volume_level = EEPROMread(600);
			choise3();
		}else if(input =='2'){		// set volume to 2
			EEPROM_write_number(600,67);
			volume_level = EEPROMread(600);
			choise3();
		}else if(input =='1'){		// set volume to 3
			EEPROM_write_number(600,33);
			volume_level = EEPROMread(600);
			choise3();
		}else if(input =='0'){		// set volume to 2
			EEPROM_write_number(600,0);
			volume_level = EEPROMread(600);
			choise3();
		}else{
			invalid();
		}	
	}
}

/* Function to get the user name */
void getusername(){	
	int i=0;
	char input;

	lcd_clrscr();
	lcd_gotoxy(0,0);  
	lcd_puts("Enter Username :");
	lcd_gotoxy(0,1);
	lcd_puts("_        #-Enter");  

	delay(1000);

	while( 1 ){
		
		input=keypad_input();
		delay(100);

		if(input=='#'){
			input=' ';
			if(i==0){			//if not enter anything 
				lcd_clrscr();
				lcd_gotoxy(0,0);  
				lcd_puts("You must Enter");
				lcd_gotoxy(0,1);  
				lcd_puts("Your Name");
				delay(3000);
				getusername();
			}else{
				transfer("User:‌ ");
				transfer(user);	//send username to PC
				transfer("\n");
				i=0;
				choise1();		//go to menu
			}
		}
		
		if(i<5){
			lcd_gotoxy(i,1);
			lcd_putc(input);	//print character while entering
		}
		if(i<4){				//print '_' as curser on LCD
			lcd_gotoxy(i+1,1);
			lcd_putc('_');
		}
		user[i]=input;
		i++;
	}

}


/* Function to print invalid input option*/
void invalid(){		
	lcd_clrscr();
	lcd_gotoxy(3, 0);
	lcd_puts("Invalid");
	lcd_gotoxy(3, 1);
	lcd_puts("Choise");
	delay(2000);
	lcd_clrscr();	
}

/* Function for easy mode leader board sub menu*/
void highscore1(){
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(submenu1);
	lcd_gotoxy(0, 1);
	lcd_puts("<-4  #-E *-B 6->");
	choise=keypad_input();
	delay(100);
	if(choise=='#'){
		scoreprint(1);
	}else if(choise=='*'){
		choise5();
	}else if(choise=='6'){
		highscore2();
	}else if(choise=='4'){
		highscore3();
	}else{
		invalid();
		highscore1();
	}
}

/* Function for Medium mode leader board sub menu*/
void highscore2(){
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(submenu2);
	lcd_gotoxy(0, 1);
	lcd_puts("<-4  #-E *-B 6->");
	choise=keypad_input();
	delay(100);
	if(choise=='#'){
		scoreprint(2);
	}else if(choise=='*'){
		choise5();
	}else if(choise=='6'){
		highscore3();
	}else if(choise=='4'){
		highscore1();
	}else{
		invalid();
		highscore2();
	}
}

/* Function for hard mode leader board sub menu*/
void highscore3(){
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(submenu3);
	lcd_gotoxy(0, 1);
	lcd_puts("<-4  #-E *-B 6->");
	choise=keypad_input();
	delay(100);
	if(choise=='#'){
		scoreprint(3);
	}else if(choise=='*'){
		choise5();
	}else if(choise=='6'){
		highscore1();
	}else if(choise=='4'){
		highscore2();
	}else{
		invalid();
		highscore3();
	}
}

/* Function to navigate in high score main menu */
void choise5(){		
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(menu5);
	lcd_gotoxy(0, 1);
	lcd_puts(press);
	choise=keypad_input();
	delay(100);
	if(choise=='#'){
		highscore1();
	}else if(choise=='6'){
		choise1();
	}else if(choise=='4'){
		choise4();
	}else{
		invalid();
		choise5();
	}
}

/* Function to navigate in username main menu */
void choise4(){		
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(menu4);
	lcd_gotoxy(0, 1);
	lcd_puts(press);
	choise=keypad_input();
	delay(100);
	if(choise=='#'){
		getusername();
	}else if(choise=='6'){
		choise5();
	}else if(choise=='4'){
		choise3();
	}else{
		invalid();
		choise4();
	}
}

/* Function to navigate in volume main menu */
void choise3(){		
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(menu3);
	lcd_gotoxy(0, 1);
	lcd_puts(press);
	choise=keypad_input();
	delay(100);
	if(choise =='#'){
		volume();
	}else if(choise =='6'){
		choise4();
	}else if(choise =='4'){
		choise2();
	}else{
		invalid();
		choise3();
	}
}

/* Function to navigate in change dfifficulty main menu */
void choise2(){		
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(menu2);
	lcd_gotoxy(0, 1);
	lcd_puts(press);
	choise = keypad_input();
	delay(100);
	if(choise =='#'){
		changeDif();
	}else if(choise =='6'){
		choise3();
	}else if(choise =='4'){
		choise1();
	}else{
		invalid();
		choise2();
	}
}

/* Function to navigate in start game main menu */
void choise1(){		
	lcd_clrscr();
	lcd_gotoxy(0, 0);	
	lcd_puts(menu1);
	lcd_gotoxy(0, 1);
	lcd_puts(press);
	choise = keypad_input();
	delay(100);
	if(choise =='#'){
		game(diff);
	}else if(choise =='6'){
		choise2();
	}else if(choise =='4'){
		choise5();
	}else{
		invalid();
		choise1();
	}
}

/* Main Function */
int main(){

    DDRB =0b001111;		//assign keypad ROW 0,1,2,3 TO PD 0,1,2,3 COL 1,2 to PD 4,5
    DDRC =0b000111;		//assign LCD RS,RW,E pins TO PC 0,1,2, PC 3 for LDR input keypad COL PC4,5
    DDRD =DDRD & ~(1<<2);	//assign pushbutton input TO PD 2

	DDRD |= (1<<5); 		//set LCD Anode pin output PD5(PWM)
	DDRC = DDRC & ~(1<<3);	//set LDR input pin TO PC 3

  	cli();					//clear global interrupts
	EIMSK &= ~(1<<INT0);	//enable interrupts for INT0  	

	lcd_init(LCD_DISP_ON);	//initializing LCD

	usart_init();  			//initializing USART
   
	init_ADC();				//initializing ADC

  	EICRA &= ~(1<<ISC00);	//set for faling edge detection [ISC00 -> 0]
  	EICRA |= (1<<ISC01);	//set for faling edge detection [ISC01 -> 1]
  	sei();					//enable global interrupts
	EIMSK |= (1<<INT0);		//enable interrupts for INT0

	srand(time(0));// use time to random_number number genarater  

////////////////////
//while(1){
	initPWM();
    	ADCSRA |= (1<<ADSC);        //Start conversion

        if(ADCSRA & (1<<ADIF)){   //execute when anolog signal convereted to digital and interupt fald become high
            OCR0A =127;     //set duty cycle in affective ADCH range
        }
//OCR0A =127;
	//brightness();//testing ???? not working


	volume_level = EEPROMread(600); 	// read last volume level

    buz_splashscreen(volume_level);		//splash screen and sound

	diff = EEPROMread(500); 			// read last difficulty level

	while(1){
		getusername();  //first getting user name
		choise1();		//go to main menu
	}
	return 0;
}

/* interrupt service routine */
ISR (INT0_vect){		//Intrrpt vector routin for push button
	buttonPushed = 1;	//set push button signal to 1
}

                    
